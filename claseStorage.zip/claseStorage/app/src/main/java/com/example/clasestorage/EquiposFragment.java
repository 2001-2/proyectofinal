package com.example.clasestorage;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class EquiposFragment extends Fragment {

    View vista;
    private RecyclerView recyclerViewEquipo;
    private EquipoRecyclerViewAdapter adapterEquipo;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference mDatabase;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        // Inflate the layout for this fragment
        vista=inflater.inflate(R.layout.fragment_equipos, container, false);

        recyclerViewEquipo=(RecyclerView)vista.findViewById(R.id.recyclerEquipos);
        recyclerViewEquipo.setLayoutManager(new LinearLayoutManager(this.getContext()));
        listarEquipos();


        return vista;
    }

    private void listarEquipos(){
        mDatabase = database.getReference("equipo");
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                List<EquipoModel> equipos = new ArrayList<>();
                for(DataSnapshot equipoSnapshot: dataSnapshot.getChildren()){
                    if(equipoSnapshot.exists()){
                        EquipoModel equipoDB = new EquipoModel();
                        String idEquipo = equipoSnapshot.child("idEquipo").getValue().toString();
                        String nombre = equipoSnapshot.child("nombre").getValue().toString();
                        String descripcion = equipoSnapshot.child("descripcion").getValue().toString();
                        String logoEquipoURL = equipoSnapshot.child("logoEquipoURL").getValue().toString();
                        equipoDB.setIdEquipo(idEquipo);
                        equipoDB.setNombre(nombre);
                        equipoDB.setDescripcion(descripcion);
                        equipoDB.setLogoEquipoURL(logoEquipoURL);
                        equipos.add(equipoDB);
                    }
                }
                adapterEquipo = new EquipoRecyclerViewAdapter(equipos);
                recyclerViewEquipo.setAdapter(adapterEquipo);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


    }


}
